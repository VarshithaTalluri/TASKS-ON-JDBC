package varshitha;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Task3 
{
	public static void delete()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("delete from studentrecord where name='ravi'");
			stmt.executeUpdate("delete from studentrecord where name='varshitha'");
			
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		
	}

	public static void main(String[] args) 
	{
		Task3 t=new Task3();
		t.delete();
	}

}
