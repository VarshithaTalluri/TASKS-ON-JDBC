package varshitha;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Task6
{
	public static void get ()
	{
		
		int sid=0;
	 String name,Address,email;
	 System.out.println("enter studentid ");
	 Scanner s=new Scanner(System.in);
	 sid=s.nextInt();
	 	 try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
		Statement stmt=con.createStatement();
		ResultSet str=stmt.executeQuery("select * from studentrecord where sid='"+sid+"'");
		while(str.next())
    	{
    	   sid = str.getInt("sid");
            int marks = str.getInt("marks");
            name = str.getString("name");
            String city = str.getString("city");
            System.out.print("sid:" +sid+"  ");
            System.out.print("marks:" +marks+"  ");
            System.out.print("name:" +name+"  ");
            System.out.println("city:" +city+"  ");
            
         }
	} 
	 catch (Exception e) 
	 {
		System.out.println(e);
	}
	}
	public static void main(String[] args) 
	{
		Task6 t=new Task6();
		t.get();

	}

}
