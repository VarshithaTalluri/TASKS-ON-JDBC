package varshitha;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Insertion
{ 
	public static void insert()
	{
		int sid=0,marks=0,i=0;
		String name = null,city = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
			Statement stmt=con.createStatement();
			PreparedStatement pstmt=con.prepareStatement("insert into studentrecord values (?,?,?,?)");
			pstmt.setInt(1,  sid);
			pstmt.setString(2, name);
			pstmt.setString(3, city);
			pstmt.setInt(4,marks);
			stmt.executeUpdate("insert into studentrecord values(1001,'varshitha','hyd',80)");
			stmt.executeUpdate("insert into studentrecord values(1002,'karthik','pune',90)");
			stmt.executeUpdate("insert into studentrecord values(1003,'samatha','chennai',99)");
			stmt.executeUpdate("insert into studentrecord values(1004,'ravi','bglr',70)");
			i=pstmt.executeUpdate();
			
	    }
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public static void main(String[] args)
	{
	
		Insertion i=new Insertion();
		i.insert();
	}

}
