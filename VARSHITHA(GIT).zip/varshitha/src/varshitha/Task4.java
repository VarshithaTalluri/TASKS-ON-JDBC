package varshitha;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Task4
{
 public static void update() 
 {
	 String name,Address,email;
	 System.out.println("enter student name to update");
	 Scanner s=new Scanner(System.in);
	 name=s.next();
	 System.out.println("enter Address to update");
	 Address=s.next();
	 System.out.println("enter email to update");
	 email=s.next();
	 try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
		Statement stmt=con.createStatement();
		stmt.executeUpdate("update student set Address='"+Address+"',email='"+email+"' where name='"+name+"'");
		
	} 
	 catch (Exception e) 
	 {
		System.out.println(e);
	}
		
	 
 }
	public static void main(String[] args)
	{
      Task4 t=new Task4();
      t.update();

	}

}
