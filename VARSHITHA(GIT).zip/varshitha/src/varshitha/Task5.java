package varshitha;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Task5
{ 
	public static void getdetails()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
	    	Statement stmt=con.createStatement();
	    	ResultSet str=stmt.executeQuery("select * from student");
	    	while(str.next())
	    	{
	    		String name = str.getString("name");
	            int mobile = str.getInt("mobile");
	            String email = str.getString("email");
	            String Address = str.getString("Address");
	            String password = str.getString("password");
	            System.out.print("name:" +name+"  ");
	            System.out.print("marks:" +mobile+"  ");
	            System.out.print("gender:" +email+"  ");
	            System.out.println("Address:" +Address+"  ");
	            System.out.println("password:" +password+"  ");
	            
	         }
		} 
		catch (Exception e)
		{
		System.out.println(e);	
		}
    	
	}

	public static void main(String[] args)
	{
	Task5 t=new Task5();
	t.getdetails();
	}

}
