import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(urlPatterns= {"/reqlogin","/reqreg","/reqstaff","/reqattendance","/reqfee","/reqwelcome","/reqview","/studentview","/grades","/entergrades","/enter","/attendance","/enterattendance","/enter1"})
public class SingleController extends HttpServlet
{
	
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
	String path=req.getServletPath();
	if(path.equals("/reqlogin"))
	{
		String Name=req.getParameter("t1");
		String password=req.getParameter("t2");
		
		boolean b=new Dao().login(Name,password);
		if(b)
		{
			HttpSession session=req.getSession();
			session.setAttribute("Name",Name);
			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
			rd.forward(req,res);
		}
		else
		{
			out.print("Invalid user");
		}
	}
	else if(path.equals("/reqreg"))
	{
		String Name=req.getParameter("t1");
		long mobile=Long.parseLong(req.getParameter("t2"));		
		String email=req.getParameter("t3");		
		String Address=req.getParameter("t4");
		String password=req.getParameter("t5");
		int fee=Integer.parseInt(req.getParameter("t6"));
		boolean b=new Dao().register( Name, mobile, email, Address,password,fee);
    if(b)
    {
    	out.print("Registration done successfully");
    }
    else
    {
    	out.print("Registration failed");
    }
	}
	else if(path.equals("/reqfee"))
	{
		HttpSession session=req.getSession();
		String Name=(String) (session.getAttribute("Name"));
		int fee=Integer.parseInt(req.getParameter("t1"));
		boolean b=new Dao().fee(fee,Name);
		if(b)
		{
			out.print("payment done successfully.....");
		
		}
		else
		{
			out.print("payment failed!!!!");
		}
	}
	else if(path.equals("/reqview"))
	{
		 
		ResultSet rs=null;
		 rs=new Dao().view();
		 out.print("<body bgcolor=DACBC9><center><br><br><table border=2  cellpadding=15><tr bgcolor=skyblue><th>Name</th><th>mobile</th><th>email</th><th>Address</th><th>password</th><th>grades</th><th>attendance</th><th>fee</th><th>paid</th><th>due</th></tr></body>");
		 try {
					while(rs.next())
			   {
				   out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getLong(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getString(7)+"</td><td>"+rs.getString(8)+"</td><td>"+rs.getString(9)+"</td><td>"+rs.getString(10)+"</td></tr>");
			   }
		   } 
		 catch (Exception e)
		 {
			
			out.print(e);
		}
	}
	else if(path.equals("/studentview"))
	{
		HttpSession session=req.getSession();
		String Name=(String) (session.getAttribute("Name"));
		System.out.println("Name"+Name);
		ResultSet rs=null;
		 rs=new Dao().studentview(Name);
		 out.print("<body bgcolor=DACBC9><center><br><br><table border=2  cellpadding=15><tr bgcolor=skyblue><th>Name</th><th>mobile</th><th>email</th><th>Address</th><th>password</th><th>grades</th><th>attendance</th><th>fee</th><th>paid</th><th>due</th></tr></body>");
		 try {
					if(rs.next())
			   {
				   out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getLong(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getString(7)+"</td><td>"+rs.getString(8)+"</td><td>"+rs.getString(9)+"</td><td>"+rs.getString(10)+"</td></tr>");
			   }
		   } 
		 catch (Exception e)
		 {
			
			out.print(e);
		}
	}

	else if(path.equals("/reqstaff"))
	{
		ResultSet rs=null;
		String username = req.getParameter("t1");
		String password =req.getParameter("t2");
		boolean b=new Dao().staff(username,password);
		b=new Dao().staff(username,password);
		if(b)
		{	
			RequestDispatcher rd =req.getRequestDispatcher("enterdetails.html");
			rd.forward(req, res);
		}
		
	}
	else if(path.equals("/grades"))
	{
		
		ResultSet rs=new Dao().viewallstudents();
		out.print("<body bgcolor=DACBC9><center><table border=5 cellpadding=12><tr bgcolor=skyblue><td>Name</td><td>Enter grades</td></tr>");
		try
		{
		while(rs.next())
		{
			out.print("<tr><td>"+rs.getString(1)+"</td><td><a href=entergrades?id="+rs.getString(1)+">enter grade</a></td></tr>");
		}
		}
		catch (Exception e) 
		{
		   System.out.println(e);	
		}
	}
	else if(path.equals("/entergrades"))
	{
	  String Name=req.getParameter("id");
	  
	  out.print("<body bgcolor=DACBC9><br><br><br><h1><center>ENTER GRADES OF STUDENT</h1></center><br>");
	  
	  out.print("<center><form action=enter><tr><td>Student Name:</td><td><input type=text readonly name=t1 value="+Name+"></td></tr><br><br>");
	  out.print("<tr><td>Grade:                       </td><td><input type=text name=t2></td></tr><br><br>");
	  out.print("<tr><td><input type=submit value=submit></td></tr><br>");
	}
	else if(path.equals("/enter"))
	{
		String name=req.getParameter("t1");
		String grade=req.getParameter("t2");
		boolean b=new Dao().updateGrades(name,grade);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("grades");
			rd.forward(req, res);
		}
		else
		{
			out.print("<center>entering Grades Failed click here to <a href=grades>Go back</a></center>");
		}
	}
	else if(path.equals("/attendance"))
	{
		ResultSet rs=new Dao().viewallstudents();
		out.print("<body bgcolor=DACBC9><center><table border=5 cellpadding=12><tr bgcolor=skyblue><td>Name</td><td>Enter attendance</td></tr>");
		try
		{
		while(rs.next())
		{
			out.print("<tr><td>"+rs.getString(1)+"</td><td><a href=enterattendance?id="+rs.getString(1)+">enter attendance</a></td></tr>");
		}
		}
		catch (Exception e) 
		{
		   System.out.println(e);	
		}
	}
	else if(path.equals("/enterattendance"))
	{
		String Name=req.getParameter("id");
		out.print("<body bgcolor=DACBC9><br><br><br><br><h1><center>ENTER ATTENDANCE OF STUDENT</h1></center><br>");
		out.print("<center><form action=enter1><h2><tr><td>student Name:</td><td><input type=text readonly name=t1 value="+Name+"></h2></td></tr><br>");
		out.print("<tr><td>Attendance:</td><td><input type=text name=t2></td></tr><br><br>");
		out.print("<tr><td><input type=submit value=submit></td></tr></h2><br>");
	}
	else if(path.equals("/enter1"))
	{
		String name=req.getParameter("t1");
		String attendance=req.getParameter("t2");
		boolean b=new Dao().updateattendance(name,attendance);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("attendance");
			rd.forward(req, res);
		}
		
	      }
	
	}
}


