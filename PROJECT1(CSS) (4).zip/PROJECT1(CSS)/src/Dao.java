import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
public class Dao
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	
	public boolean login(String Name,String password)
	{
		boolean b=false;
		
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try {
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select Name,password from student where Name='"+Name+"' and password='"+password+"'");
		if(rs.next())
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return b;
	}
	
	public boolean register(String Name,Long mobile,String email,String Address,String password,int fee)
	{
		boolean b=false;
		String grades=null;int attendance=0;int  paid=0;int due=0 ;
		int i=0;
		con=Dao.getConnectionObject();
		try {
			PreparedStatement pstmt=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?)");
		
			pstmt.setString(1, Name);
			pstmt.setLong(2, mobile);
			pstmt.setString(3, email);
			pstmt.setString(4, Address);
			pstmt.setString(5, password);
			pstmt.setString(6,null);
			pstmt.setString(7, null);
			pstmt.setInt(8,fee);
			pstmt.setInt(9, 0);
			pstmt.setInt(10,fee);
			i=pstmt.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean fee(int fee,String Name)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
			
			Statement stmt=con.createStatement();
			System.out.println("name:"+Name);
			int i=stmt.executeUpdate("update student set paid=paid+'"+fee+"'where Name='"+Name+"'");
			if (i>0)
			{
				int j=stmt.executeUpdate("update student set due=due-'"+fee+"' where Name='"+Name+"'");
				if(j>0)
				{
					b=true;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
}
	public ResultSet view()
	{
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try 
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from student order by name");
		} 
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		return rs;
	}

	public ResultSet studentview(String Name)
	{
		
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try 
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from student where name='"+Name+"'");
		} 
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		return rs;
	}
	
	public boolean staff(String username,String password)
	{
		boolean b=false;
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try {
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select username,password from staff where username='"+username+"' and password='"+password+"'");
		if(rs.next())
		{
         b=true;
           
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return b;
		
	}
	public ResultSet viewallstudents()
	{
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
		   Statement st=con.createStatement();
		   rs=st.executeQuery("select Name from student");
		}
		catch (Exception e)
		{
		    System.out.println(e);
		}
		return rs;
	}
	public boolean updateGrades(String name,String grade)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
		Statement st=con.createStatement();
		int i=st.executeUpdate("update student set grades='"+grade+"' where Name='"+name+"'");
		if(i>0)
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
				return b;
	}
	public boolean updateattendance(String name,String attendance)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
		Statement st=con.createStatement();
		int i=st.executeUpdate("update student set attendance='"+attendance+"' where Name='"+name+"'");
		if(i>0)
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
}
