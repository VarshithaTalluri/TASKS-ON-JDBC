import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteController extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)
	{
		Connection con=null;
		int i=0;
	    String Name=req.getParameter("del");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
		
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("delete from student where Name='"+Name+"'");
            if(i>0)
            {
            	RequestDispatcher rd=req.getRequestDispatcher("view");
            	rd.forward(req,res);
            }

	    }
		catch(Exception e)
		{
			System.out.println(e);
		}
    }
}
