import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.Resultset;

public class LoginController extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		String Name=req.getParameter("t1");
		String password=req.getParameter("t2");
		ResultSet rs=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select Name,password from student where Name='"+Name+"' and password='"+password+"'");
			if(Name.equals("admin")&& password.equals("admin"))
			{
				Cookie ck=new Cookie("name", Name);
			      res.addCookie(ck);
				
				RequestDispatcher rd=req.getRequestDispatcher("reqwelcome");
				rd.forward(req, res);
		    } 
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("index.html");
				rd.include(req, res);
				out.print("Invalid username/password");
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}

}
}
