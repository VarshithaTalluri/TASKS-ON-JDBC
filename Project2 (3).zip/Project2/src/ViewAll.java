import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewAll extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
{
	PrintWriter out=res.getWriter();
	Connection con=null;
	ResultSet rs=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select * from student");
		out.print("<table border=4 cellpadding=8><tr bgcolor=#33FCFF><td>Name</td><td>mobile</td><td>email</td><td>Address</td><td>password</td><td>updateuser</td><td>deleteuser</td></tr>");
		while(rs.next())
		{
			out.print("<body><tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td><a href=requpdate?id="+rs.getString(1)+">Update</a></td><td><a href=reqdelete?del="+rs.getString(1)+">delete</a></td></tr>");
		}
      }
	catch(Exception e)
	{
		System.out.print(e);
	}
}
}
