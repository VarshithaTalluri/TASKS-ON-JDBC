import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateController extends HttpServlet
{
  public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
  {
	  PrintWriter out=res.getWriter();
	  String Name=req.getParameter("id");
	  try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/varshitha", "root","varshitha@947");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from student where Name='"+Name+"'");
		if(rs.next())
	      {
	    	  out.print("<body><form action=updatedetails>Name : <input type=text name= t1 readonly value="+rs.getString(1)+"><br>");
	    	  out.print("mobile : <input type=text name=t2 value="+rs.getLong(2)+" ><br>");
	    	  out.print("email : <input type=text name=t3 value="+rs.getString(3)+"><br>");
	    	  out.print("Address:<input type=text name=t4 value="+rs.getString(4)+"><br>");
	    	  out.print("password:<input type=text name=t5 value="+rs.getString(5)+"><br>");
	    	  out.print("<input type=submit value=Update><input type=Reset value=clear></form>");
	    }
	     } 
	  catch (Exception e)
	  {
		out.print(e);
	 } 
	
}
}
